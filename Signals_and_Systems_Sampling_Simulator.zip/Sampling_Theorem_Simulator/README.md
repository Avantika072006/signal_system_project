# Sampling Theorem & Aliasing Simulator

## Project overview
An interactive Python simulation that demonstrates:
- A continuous-time sine wave
- Sampling at a selected sampling frequency
- The Nyquist sampling condition (`fs >= 2 * fm`)
- Aliasing when the sampling frequency is too low
- Approximate sinc-based reconstruction

## Requirements
- Python 3.9+
- Streamlit
- NumPy
- Matplotlib

## Setup and run
```bash
python -m venv venv
```

Activate the environment:

**Windows**
```bash
venv\Scripts\activate
```

**macOS/Linux**
```bash
source venv/bin/activate
```

Install packages and run:
```bash
pip install -r requirements.txt
streamlit run app.py
```

The app opens in your browser. Change the sliders to experiment with different signal and sampling frequencies.

## Suggested experiment
1. Set `fm = 5 Hz` and `fs = 20 Hz`.
2. Observe the sampled points and reconstruction.
3. Reduce `fs` to `6 Hz`.
4. Observe the aliasing warning and the difference in reconstruction.
5. Increase `fs` to `40 Hz` and compare.

## Main formula
Nyquist rate: `fs = 2fm`

For ideal reconstruction, the sampling frequency must be at least twice the highest frequency present in the signal.
