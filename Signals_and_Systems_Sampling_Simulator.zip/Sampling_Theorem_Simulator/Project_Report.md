# Mini Project Report
## Title
**Simulation of Sampling Theorem and Aliasing Using Python**

## 1. Aim
To simulate the sampling of a continuous-time sinusoidal signal and study the effect of sampling frequency on signal reconstruction.

## 2. Objectives
- Generate a sinusoidal message signal.
- Sample the signal at a user-selected sampling frequency.
- Verify the Nyquist sampling criterion.
- Observe aliasing when the sampling frequency is insufficient.
- Visualize approximate signal reconstruction using sinc interpolation.

## 3. Software and Libraries
Python, Streamlit, NumPy, and Matplotlib.

## 4. Theory
A continuous-time sinusoidal signal can be represented as:

`x(t) = sin(2πfmt + φ)`

where `fm` is the message frequency and `φ` is the phase.

Sampling measures the signal at equally spaced time instants:

`ts = n/fs`

The Nyquist-Shannon sampling theorem states that a band-limited signal can be ideally reconstructed if its sampling frequency is at least twice its highest frequency:

`fs ≥ 2fm`

If `fs < 2fm`, aliasing can occur. Aliasing makes a higher-frequency signal appear as a different lower-frequency signal after sampling.

## 5. Methodology
1. Select message frequency, sampling frequency, duration, and phase.
2. Generate a dense time axis to display the continuous-time waveform.
3. Calculate sample instants and sample amplitudes.
4. Compare the sampling frequency with twice the message frequency.
5. Plot the original waveform and sampled points.
6. Apply a finite sinc-interpolation sum to visualize reconstruction.

## 6. Expected Observations
- When `fs ≥ 2fm`, the Nyquist condition is satisfied.
- When `fs < 2fm`, aliasing may occur.
- Increasing the sampling frequency provides more samples per cycle and generally improves the displayed reconstruction.

## 7. Result
The Python simulation illustrates the relationship between message frequency and sampling frequency. It visually demonstrates the Nyquist criterion and the effect of undersampling.

## 8. Conclusion
The project shows why selecting an adequate sampling frequency is essential in digital signal processing. Sampling below the Nyquist rate can cause aliasing and prevent unique recovery of the original signal.

## 9. Applications
- Digital audio recording
- Image and video processing
- Communication systems
- Biomedical signal acquisition
- Measurement and instrumentation
