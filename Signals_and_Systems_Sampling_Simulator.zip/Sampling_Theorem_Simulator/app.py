import streamlit as st
import numpy as np
import matplotlib.pyplot as plt

st.set_page_config(page_title="Sampling Theorem Simulator", page_icon="📡", layout="wide")

st.title("📡 Sampling Theorem & Aliasing Simulator")
st.write(
    "Explore how a continuous-time sine wave is sampled, and see why the sampling "
    "frequency must be high enough to reconstruct the original signal."
)

st.sidebar.header("Signal controls")
fm = st.sidebar.slider("Message frequency, fm (Hz)", 1.0, 20.0, 5.0, 0.5)
fs = st.sidebar.slider("Sampling frequency, fs (Hz)", 2.0, 80.0, 20.0, 1.0)
duration = st.sidebar.slider("Signal duration (seconds)", 0.5, 3.0, 1.0, 0.1)
phase_deg = st.sidebar.slider("Phase (degrees)", 0, 180, 0, 5)

phase = np.deg2rad(phase_deg)
nyquist = 2 * fm
is_valid = fs >= nyquist

# Dense time axis approximates the continuous-time signal for visualization.
t = np.linspace(0, duration, 4000)
x = np.sin(2 * np.pi * fm * t + phase)

# Sample instants and sampled signal.
n = np.arange(0, int(np.floor(duration * fs)) + 1)
ts = n / fs
xs = np.sin(2 * np.pi * fm * ts + phase)

st.subheader("Sampling condition")
c1, c2, c3 = st.columns(3)
c1.metric("Message frequency", f"{fm:.1f} Hz")
c2.metric("Sampling frequency", f"{fs:.1f} Hz")
c3.metric("Nyquist rate (2fm)", f"{nyquist:.1f} Hz")

if is_valid:
    st.success("Nyquist condition satisfied: fs ≥ 2fm. Sampling is theoretically sufficient.")
else:
    st.warning("Aliasing may occur: fs < 2fm. The sampled points cannot uniquely represent the original frequency.")

fig, ax = plt.subplots(figsize=(11, 4.5))
ax.plot(t, x, label="Original signal x(t)", linewidth=2)
ax.stem(ts, xs, linefmt="C1-", markerfmt="C1o", basefmt=" ", label="Samples")
ax.set_title("Original signal and its samples")
ax.set_xlabel("Time (seconds)")
ax.set_ylabel("Amplitude")
ax.grid(True, alpha=0.3)
ax.legend()
st.pyplot(fig)
plt.close(fig)

# Ideal sinc reconstruction from the available samples.
# This finite sum is a practical visualization, not a perfect infinite-duration ideal filter.
tr = np.linspace(0, duration, 2500)
xr = np.zeros_like(tr)
for sample_time, sample_value in zip(ts, xs):
    xr += sample_value * np.sinc(fs * (tr - sample_time))

fig2, ax2 = plt.subplots(figsize=(11, 4.5))
ax2.plot(t, x, label="Original signal", linewidth=2)
ax2.plot(tr, xr, "--", label="Sinc reconstruction from samples", linewidth=1.8)
ax2.stem(ts, xs, linefmt="C1-", markerfmt="C1o", basefmt=" ", label="Samples")
ax2.set_title("Signal reconstruction using sinc interpolation")
ax2.set_xlabel("Time (seconds)")
ax2.set_ylabel("Amplitude")
ax2.grid(True, alpha=0.3)
ax2.legend()
st.pyplot(fig2)
plt.close(fig2)

st.subheader("What to observe")
if is_valid:
    st.write(
        "- The sampling frequency is at least twice the message frequency.\n"
        "- The samples capture enough information to represent the original frequency.\n"
        "- Reconstruction improves as the sampling frequency is increased."
    )
else:
    st.write(
        "- The sampling frequency is below twice the message frequency.\n"
        "- Different continuous-time signals can produce the same samples (aliasing).\n"
        "- Increase fs to at least 2fm to satisfy the Nyquist criterion."
    )

st.info(
    "Theory: For a band-limited signal with highest frequency fm, the Nyquist-Shannon "
    "sampling theorem requires fs ≥ 2fm for ideal reconstruction."
)

with st.expander("Project conclusion"):
    st.write(
        "This simulation demonstrates the sampling theorem. When the sampling frequency "
        "is below the Nyquist rate, aliasing occurs and the original signal cannot be "
        "uniquely recovered. Sampling at or above twice the highest signal frequency "
        "avoids aliasing in the ideal theorem."
    )
